## Available Scripts
In the project directory, you can run:

### server
- `mongodb download`
https://www.mongodb.com/download-center

- `npm i`
Install npm modules

- `npm start`
Open http://localhost:4500/user

### client
- `npm i`
Install npm modules

- `npm start`
Open http://localhost:3000


