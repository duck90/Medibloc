## Available Scripts
In the project directory, you can run:

### `npm i`
Install npm modules

### `npm start`
Open http://localhost:3000