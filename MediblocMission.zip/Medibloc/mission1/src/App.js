import React from 'react';
import Home from './view/home'
import './App.css';

function App() {
  return (
    <div>
      <Home/>
    </div>
  );
}

export default App;
